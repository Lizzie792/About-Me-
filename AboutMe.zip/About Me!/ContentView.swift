//
//  ContentView.swift
//  About Me!
//
//  Created by scholar on 7/13/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack{
            VStack(spacing: 0.0){
                
                Text("All About Me!")
                    .font(.largeTitle)
                    .fontWeight(.regular)
                
                
                VStack(spacing: 0.0){
                    VStack{
                        Image("modern")
                            .renderingMode(.none)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .padding([.top, .leading, .trailing], 33.0)
                            .cornerRadius(15)
                    }
                    Button("Learn more"){
                        Text("I love to dance - specifically contemporary, I have been coding since the 4th grade, I have a dog named Nori, I work at Burlington, and I love starting new projects.")
                    }
                    .font(.title2)
                    
                    .padding()
                    .buttonStyle(.borderedProminent)
                    .tint(.purple)
                }
                .padding(.bottom, -90.0)
            }
            
        }
        .padding(.top, -200.0)
    }
}
        
        struct ContentView_Previews: PreviewProvider {
            static var previews: some View {
                ContentView()
            }
        }

