//
//  About_Me_App.swift
//  About Me!
//
//  Created by scholar on 7/13/23.
//

import SwiftUI

@main
struct About_Me_App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
